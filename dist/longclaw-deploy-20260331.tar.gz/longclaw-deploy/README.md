# LongClaw 部署指南

## 系统要求

- **Python**: 3.10 或更高版本
- **Node.js**: 18 或更高版本
- **npm**: 8 或更高版本
- **MySQL/MariaDB**: 5.7 或更高版本 (支持 UTF8MB4)
- **Redis**: 6 或更高版本
- **内存**: 最少 2GB，推荐 4GB+

## 快速开始

### 1. 运行安装脚本

```bash
chmod +x setup.sh
./setup.sh
```

安装脚本会引导你完成以下配置：
- 数据库连接信息
- Redis 连接信息
- API 密钥设置
- LLM 模型配置
- 服务端口配置

### 2. 启动服务

安装完成后，服务会自动启动。如果没有自动启动，可以使用：

```bash
# 开发模式
./start-dev.sh

# 生产模式 (需要 systemd)
./start.sh
```

### 3. 访问服务

- 前端界面: http://localhost:5173
- 后端 API: http://localhost:8001
- API 文档: http://localhost:8001/docs

## 管理命令

```bash
# 停止服务
./stop.sh

# 检查状态
./status.sh

# 查看后端日志
tail -f /var/log/longclaw/backend.log

# 查看前端日志
tail -f /var/log/longclaw/frontend.log
```

## 配置说明

### 环境变量

配置文件位于 `backend/.env`，主要配置项：

```env
# 服务器配置
HOST=0.0.0.0
PORT=8001

# 数据库配置
DB_HOST=localhost
DB_PORT=3306
DB_NAME=longclaw
DB_USER=longclaw
DB_PASSWORD=your_password

# Redis 配置
REDIS_HOST=localhost
REDIS_PORT=6379

# API 认证
API_KEY=your_api_key

# LLM 模型配置
LLM_DEFAULT_PROVIDER=openai
OPENAI_API_KEY=your_api_key
OPENAI_MODEL=gpt-4o
```

### 数据库初始化

如果需要重新初始化数据库：

```bash
cd /opt/longclaw
source /var/lib/longclaw/venv/bin/activate
PYTHONPATH=. python scripts/init_db.py --force
```

## 生产环境部署

### 使用 systemd 服务

```bash
# 安装服务
sudo ./setup.sh --production

# 启动服务
sudo ./start.sh

# 设置开机自启
sudo systemctl enable longclaw-backend
sudo systemctl enable longclaw-frontend
```

### Nginx 反向代理配置

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:5173;
        proxy WebSocket Upgrade;
    }

    location /api {
        proxy_pass http://127.0.0.1:8001;
        proxy_set_header Host $host;
    }

    location /ws {
        proxy_pass http://127.0.0.1:8001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

## 常见问题

### Q: 安装脚本提示缺少依赖
A: 请使用包管理器安装，例如：
```bash
# Ubuntu/Debian
sudo apt-get install python3 python3-pip nodejs npm mysql-client redis-server

# CentOS/RHEL
sudo yum install python3 python3-pip nodejs npm mysql redis
```

### Q: 数据库连接失败
A: 检查 MySQL/MariaDB 是否运行：
```bash
sudo systemctl status mysql
```

### Q: Redis 连接失败
A: 检查 Redis 是否运行：
```bash
sudo systemctl status redis
```

### Q: 前端无法访问后端 API
A: 检查后端服务是否正常运行：
```bash
curl http://localhost:8001/health
```

## 技术支持

如有问题，请提交 Issue 或联系开发者。
