import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:8001',
        changeOrigin: true,
        ws: true,  // Enable WebSocket proxying for /api routes
      },
      '/ws': {
        target: 'ws://localhost:8001',
        ws: true,  // Enable WebSocket proxying
      },
    },
  },
})
