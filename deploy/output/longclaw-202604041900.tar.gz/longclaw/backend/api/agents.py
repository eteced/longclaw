"""
Agents API for LongClaw.
"""
from datetime import datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database import db_manager
from backend.models.agent import Agent, AgentStatus, AgentType
from backend.services.agent_service import agent_service
from backend.services.message_service import message_service

router = APIRouter()


# ==================== Schemas ====================


class ModelAssignmentInfo(BaseModel):
    """Schema for model assignment information."""
    provider: str | None = None
    model: str | None = None
    slot_id: str | None = None
    slot_index: int | None = None


class AgentResponse(BaseModel):
    """Schema for agent response."""

    id: str
    agent_type: AgentType
    name: str
    personality: str | None
    status: AgentStatus
    error_message: str | None = None
    parent_agent_id: str | None
    task_id: str | None
    llm_config: dict[str, Any] | None = Field(None, alias="model_config")
    model_assignment: ModelAssignmentInfo | None = None
    created_at: datetime
    updated_at: datetime
    terminated_at: datetime | None

    class Config:
        from_attributes = True
        populate_by_name = True


def _convert_agent_to_response(agent: Agent) -> AgentResponse:
    """Convert Agent model to AgentResponse with model_assignment."""
    model_assign = None
    if agent.model_assignment:
        ma = agent.model_assignment
        model_assign = ModelAssignmentInfo(
            provider=ma.get("provider"),
            model=ma.get("model"),
            slot_id=ma.get("slot_id"),
            slot_index=ma.get("slot_index"),
        )
    
    return AgentResponse(
        id=agent.id,
        agent_type=agent.agent_type,
        name=agent.name,
        personality=agent.personality,
        status=agent.status,
        error_message=agent.error_message,
        parent_agent_id=agent.parent_agent_id,
        task_id=agent.task_id,
        model_config=agent.model_assignment,
        model_assignment=model_assign,
        created_at=agent.created_at,
        updated_at=agent.updated_at,
        terminated_at=agent.terminated_at,
    )


class AgentListResponse(BaseModel):
    """Schema for agent list response."""

    items: list[AgentResponse]
    total: int
    limit: int
    offset: int


class AgentSummaryResponse(BaseModel):
    """Schema for agent summary response."""

    agent_id: str
    summary: str


# ==================== Dependency ====================


async def get_session() -> AsyncSession:
    """Get database session dependency.

    Yields:
        AsyncSession instance.
    """
    async with db_manager.session() as session:
        yield session


# ==================== Endpoints ====================


@router.get("", response_model=AgentListResponse)
async def list_agents(
    agent_type: AgentType | None = Query(None, description="Filter by agent type"),
    status: AgentStatus | None = Query(None, description="Filter by status"),
    task_id: str | None = Query(None, description="Filter by task ID"),
    limit: int = Query(20, ge=1, le=100, description="Number of results"),
    offset: int = Query(0, ge=0, description="Offset for pagination"),
    session: AsyncSession = Depends(get_session),
) -> AgentListResponse:
    """List agents with optional filtering.

    Args:
        agent_type: Optional agent type filter.
        status: Optional status filter.
        task_id: Optional task ID filter.
        limit: Maximum number of results.
        offset: Offset for pagination.
        session: Database session.

    Returns:
        List of agents.
    """
    agents = await agent_service.get_agents(
        session,
        agent_type=agent_type,
        status=status,
        task_id=task_id,
        limit=limit,
        offset=offset,
    )
    total = await agent_service.count_agents(
        session,
        agent_type=agent_type,
        status=status,
        task_id=task_id,
    )

    return AgentListResponse(
        items=[_convert_agent_to_response(a) for a in agents],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get("/{agent_id}", response_model=AgentResponse)
async def get_agent(
    agent_id: str,
    session: AsyncSession = Depends(get_session),
) -> Agent:
    """Get an agent by ID.

    Args:
        agent_id: Agent ID.
        session: Database session.

    Returns:
        Agent details.

    Raises:
        HTTPException: If agent not found.
    """
    agent = await agent_service.get_agent(session, agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    return agent


@router.get("/{agent_id}/messages")
async def get_agent_messages(
    agent_id: str,
    limit: int = Query(50, ge=1, le=200, description="Number of results"),
    offset: int = Query(0, ge=0, description="Offset for pagination"),
    session: AsyncSession = Depends(get_session),
) -> list[dict[str, Any]]:
    """Get messages involving an agent.

    Args:
        agent_id: Agent ID.
        limit: Maximum number of results.
        offset: Offset for pagination.
        session: Database session.

    Returns:
        List of messages.

    Raises:
        HTTPException: If agent not found.
    """
    agent = await agent_service.get_agent(session, agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    messages = await message_service.get_agent_messages(
        session, agent_id, limit=limit, offset=offset
    )

    return [
        {
            "id": m.id,
            "sender_type": m.sender_type.value,
            "sender_id": m.sender_id,
            "receiver_type": m.receiver_type.value,
            "receiver_id": m.receiver_id,
            "message_type": m.message_type.value,
            "content": m.content,
            "task_id": m.task_id,
            "created_at": m.created_at.isoformat(),
        }
        for m in messages
    ]


@router.get("/{agent_id}/summary", response_model=AgentSummaryResponse)
async def get_agent_summary(
    agent_id: str,
    session: AsyncSession = Depends(get_session),
) -> AgentSummaryResponse:
    """Get an agent's summary.

    Args:
        agent_id: Agent ID.
        session: Database session.

    Returns:
        Agent summary.

    Raises:
        HTTPException: If agent not found.
    """
    agent = await agent_service.get_agent(session, agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    # Extract summary from personality if exists
    summary = ""
    if agent.personality:
        parts = agent.personality.split("\n\nLast Summary: ")
        if len(parts) > 1:
            summary = parts[1]

    return AgentSummaryResponse(agent_id=agent_id, summary=summary)
