# LongClaw 部署指南

## 系统要求

- **Python**: 3.10 或更高版本
- **Node.js**: 18 或更高版本
- **npm**: 8 或更高版本
- **MySQL/MariaDB**: 5.7 或更高版本 (支持 UTF8MB4)
- **Redis**: 6 或更高版本
- **内存**: 最少 2GB，推荐 4GB+

## 快速开始

### 1. 运行安装脚本

```bash
chmod +x install.sh
./install.sh
```

安装脚本会引导你完成以下配置：
- 数据库连接信息
- Redis 连接信息
- API 密钥设置
- LLM 模型配置
- 服务端口配置

### 2. 启动服务

安装完成后，服务会自动启动。如果没有自动启动，可以使用：

```bash
# 启动后端
cd backend
source venv/bin/activate
PYTHONPATH=. uvicorn main:app --host 0.0.0.0 --port 8001

# 启动前端
cd frontend
npm run dev
```

### 3. 访问服务

- 前端界面: http://localhost:5173
- 后端 API: http://localhost:8001
- API 文档: http://localhost:8001/docs

## 配置说明

### 环境变量

配置文件位于 `backend/.env`，主要配置项：

```env
# 服务器配置
HOST=0.0.0.0
PORT=8001

# 数据库配置
DB_HOST=localhost
DB_PORT=3306
DB_NAME=longclaw
DB_USER=longclaw
DB_PASSWORD=your_password

# Redis 配置
REDIS_HOST=localhost
REDIS_PORT=6379

# API 认证
API_KEY=your_api_key

# LLM 模型配置
LLM_DEFAULT_PROVIDER=openai
OPENAI_API_KEY=your_api_key
OPENAI_MODEL=gpt-4o
```

### 数据库初始化

如果需要重新初始化数据库：

```bash
cd /opt/longclaw
source venv/bin/activate
PYTHONPATH=. python scripts/init_db.py --force
```

## 管理命令

```bash
# 停止服务
pkill -f uvicorn
pkill -f vite

# 检查后端状态
curl http://localhost:8001/health

# 查看后端日志
tail -f backend.log
```

## 常见问题

### Q: 安装脚本提示缺少依赖
A: 请使用包管理器安装，例如：
```bash
# Ubuntu/Debian
sudo apt-get install python3 python3-pip nodejs npm mysql-client redis-server

# CentOS/RHEL
sudo yum install python3 python3-pip nodejs npm mysql redis
```

### Q: 数据库连接失败
A: 检查 MySQL/MariaDB 是否运行：
```bash
sudo systemctl status mysql
```

### Q: Redis 连接失败
A: 检查 Redis 是否运行：
```bash
sudo systemctl status redis
```

### Q: 前端无法访问后端 API
A: 检查后端服务是否正常运行：
```bash
curl http://localhost:8001/health
```

## 技术支持

如有问题，请联系开发者。
