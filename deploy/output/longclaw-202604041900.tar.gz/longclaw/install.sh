#!/bin/bash
#
# LongClaw 安装部署脚本
# ================================
# 此脚本在目标服务器上运行，安装和配置 LongClaw
#

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查是否为 root 用户
check_root() {
    if [ "$EUID" -ne 0 ]; then
        log_warning "建议使用 root 用户运行此脚本，或使用 sudo"
    fi
}

# 检测操作系统
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$ID
        VER=$VERSION_ID
    else
        OS="unknown"
        VER="unknown"
    fi
    log_info "检测到操作系统: $OS $VER"
}

# 检查依赖
check_dependencies() {
    log_info "检查系统依赖..."

    local missing_deps=()

    # 检查 Python
    if ! command -v python3 &> /dev/null; then
        missing_deps+=("python3")
    else
        PYTHON_VERSION=$(python3 --version 2>&1 | cut -d' ' -f2)
        log_info "Python 版本: $PYTHON_VERSION"
    fi

    # 检查 Node.js
    if ! command -v node &> /dev/null; then
        missing_deps+=("nodejs")
    else
        NODE_VERSION=$(node --version 2>&1)
        log_info "Node.js 版本: $NODE_VERSION"
    fi

    # 检查 npm
    if ! command -v npm &> /dev/null; then
        missing_deps+=("npm")
    else
        NPM_VERSION=$(npm --version 2>&1)
        log_info "npm 版本: $NPM_VERSION"
    fi

    # 检查 MySQL
    if ! command -v mysql &> /dev/null; then
        log_warning "MySQL 客户端未安装"
    else
        log_info "MySQL 客户端已安装"
    fi

    # 检查 Redis
    if ! command -v redis-cli &> /dev/null; then
        log_warning "Redis 客户端未安装"
    else
        log_info "Redis 客户端已安装"
    fi

    # 如果有缺失依赖，提示安装
    if [ ${#missing_deps[@]} -gt 0 ]; then
        log_error "缺少以下依赖: ${missing_deps[*]}"
        echo ""
        echo "请先安装依赖:"
        echo "  Ubuntu/Debian: apt-get install ${missing_deps[*]} mysql-server redis-server"
        echo "  CentOS/RHEL:   yum install ${missing_deps[*]} mysql-server redis"
        echo ""
        read -p "是否现在安装? (y/n) " -n 1 -r
        echo ""
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            install_dependencies
        else
            log_error "无法继续，缺少必要依赖"
            exit 1
        fi
    fi
}

# 安装依赖
install_dependencies() {
    log_info "安装系统依赖..."

    if [ "$OS" = "ubuntu" ] || [ "$OS" = "debian" ]; then
        apt-get update
        apt-get install -y python3 python3-pip python3-venv nodejs npm mysql-server redis-server
    elif [ "$OS" = "centos" ] || [ "$OS" = "rhel" ] || [ "$OS" = "rocky" ]; then
        yum install -y python3 python3-pip nodejs npm mysql-server redis
    else
        log_warning "未知操作系统，请手动安装依赖"
    fi

    log_success "依赖安装完成"
}

# 配置 MySQL
setup_mysql() {
    log_info "配置 MySQL..."

    # 检查 MySQL 是否运行
    if systemctl is-active --quiet mysql 2>/dev/null || systemctl is-active --quiet mysqld 2>/dev/null; then
        log_info "MySQL 服务正在运行"
    else
        log_info "启动 MySQL 服务..."
        if command -v systemctl &> /dev/null; then
            systemctl start mysql 2>/dev/null || systemctl start mysqld 2>/dev/null || true
        fi
    fi

    # 读取 MySQL 配置
    echo ""
    read -p "MySQL 主机 [localhost]: " DB_HOST
    DB_HOST=${DB_HOST:-localhost}

    read -p "MySQL 端口 [3306]: " DB_PORT
    DB_PORT=${DB_PORT:-3306}

    read -p "MySQL 用户名 [longclaw]: " DB_USER
    DB_USER=${DB_USER:-longclaw}

    read -s -p "MySQL 密码: " DB_PASSWORD
    echo ""

    read -p "数据库名称 [longclaw]: " DB_NAME
    DB_NAME=${DB_NAME:-longclaw}

    # 创建数据库和用户
    log_info "创建数据库和用户..."
    mysql -u root << EOF || true
CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASSWORD';
CREATE USER IF NOT EXISTS '$DB_USER'@'%' IDENTIFIED BY '$DB_PASSWORD';
GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'localhost';
GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'%';
FLUSH PRIVILEGES;
EOF

    log_success "MySQL 配置完成"
}

# 配置 Redis
setup_redis() {
    log_info "配置 Redis..."

    # 检查 Redis 是否运行
    if systemctl is-active --quiet redis 2>/dev/null || systemctl is-active --quiet redis-server 2>/dev/null; then
        log_info "Redis 服务正在运行"
    else
        log_info "启动 Redis 服务..."
        if command -v systemctl &> /dev/null; then
            redis-server --daemonize yes 2>/dev/null || systemctl start redis 2>/dev/null || systemctl start redis-server 2>/dev/null || true
        else
            redis-server --daemonize yes 2>/dev/null || true
        fi
    fi

    read -p "Redis 主机 [localhost]: " REDIS_HOST
    REDIS_HOST=${REDIS_HOST:-localhost}

    read -p "Redis 端口 [6379]: " REDIS_PORT
    REDIS_PORT=${REDIS_PORT:-6379}

    log_success "Redis 配置完成"
}

# 配置后端
setup_backend() {
    log_info "配置后端..."

    cd "$SCRIPT_DIR/backend"

    # 创建虚拟环境
    log_info "创建 Python 虚拟环境..."
    python3 -m venv venv
    source venv/bin/activate

    # 安装依赖
    log_info "安装 Python 依赖..."
    pip install --upgrade pip
    pip install -r requirements.txt

    # 配置环境变量
    log_info "配置环境变量..."

    # 读取 API 配置
    read -p "API 密钥 [自动生成]: " API_KEY
    if [ -z "$API_KEY" ]; then
        API_KEY="longclaw_admin_$(date +%s)"
    fi

    # LLM 配置
    echo ""
    echo "LLM 模型配置:"
    read -p "默认模型提供商 [openai]: " LLM_PROVIDER
    LLM_PROVIDER=${LLM_PROVIDER:-openai}

    read -p "OpenAI API Key: " OPENAI_API_KEY
    read -p "OpenAI Base URL [http://localhost:3721/v1]: " OPENAI_BASE_URL
    OPENAI_BASE_URL=${OPENAI_BASE_URL:-http://localhost:3721/v1}
    read -p "OpenAI 模型名称: " OPENAI_MODEL

    # 写入配置文件
    cat > .env << EOF
# Server
HOST=0.0.0.0
PORT=8001
DEBUG=false

# API Authentication
API_KEY=$API_KEY

# Database
DB_HOST=$DB_HOST
DB_PORT=$DB_PORT
DB_NAME=$DB_NAME
DB_USER=$DB_USER
DB_PASSWORD=$DB_PASSWORD

# Redis
REDIS_HOST=$REDIS_HOST
REDIS_PORT=$REDIS_PORT
REDIS_DB=0

# LLM Configuration
LLM_DEFAULT_PROVIDER=$LLM_PROVIDER
OPENAI_API_KEY=$OPENAI_API_KEY
OPENAI_BASE_URL=$OPENAI_BASE_URL
OPENAI_MODEL=$OPENAI_MODEL
EOF

    deactivate

    log_success "后端配置完成"
}

# 配置前端
setup_frontend() {
    log_info "配置前端..."

    cd "$SCRIPT_DIR/frontend"

    # 安装依赖
    log_info "安装前端依赖..."
    npm install

    # 构建前端
    log_info "构建前端..."
    npm run build

    log_success "前端配置完成"
}

# 初始化数据库
init_database() {
    log_info "初始化数据库..."

    cd "$SCRIPT_DIR/backend"
    source venv/bin/activate
    PYTHONPATH=. python scripts/init_db.py

    log_success "数据库初始化完成"
}

# 启动服务
start_services() {
    log_info "启动服务..."

    # 创建日志目录
    mkdir -p /var/log/longclaw 2>/dev/null || true

    # 启动后端
    log_info "启动后端服务..."
    cd "$SCRIPT_DIR/backend"
    source venv/bin/activate

    nohup python -c "
import uvicorn
import os
os.environ['PYTHONPATH'] = '.'
uvicorn.run('main:app', host='0.0.0.0', port=8001, log_level='info')
" > /var/log/longclaw/backend.log 2>&1 &

    BACKEND_PID=$!
    echo $BACKEND_PID > /tmp/longclaw_backend.pid
    log_info "后端服务 PID: $BACKEND_PID"

    # 等待后端启动
    sleep 3

    # 检查后端是否启动成功
    if curl -s http://localhost:8001/health > /dev/null 2>&1; then
        log_success "后端服务启动成功"
    else
        log_warning "后端服务可能未正常启动，请检查日志"
    fi

    # 启动前端
    log_info "启动前端服务..."
    cd "$SCRIPT_DIR/frontend"

    nohup npm run dev > /var/log/longclaw/frontend.log 2>&1 &

    FRONTEND_PID=$!
    echo $FRONTEND_PID > /tmp/longclaw_frontend.pid
    log_info "前端服务 PID: $FRONTEND_PID"

    sleep 3

    log_success "服务启动完成"
}

# 显示服务状态
show_status() {
    echo ""
    echo "=============================================="
    echo "  LongClaw 部署完成!"
    echo "=============================================="
    echo ""
    echo "  服务地址:"
    echo "  - 前端界面: http://localhost:5173"
    echo "  - 后端 API:  http://localhost:8001"
    echo "  - API 文档:  http://localhost:8001/docs"
    echo ""
    echo "  服务进程:"
    echo "  - 后端 PID: $(cat /tmp/longclaw_backend.pid 2>/dev/null || echo 'N/A')"
    echo "  - 前端 PID: $(cat /tmp/longclaw_frontend.pid 2>/dev/null || echo 'N/A')"
    echo ""
    echo "  日志文件:"
    echo "  - 后端日志: /var/log/longclaw/backend.log"
    echo "  - 前端日志: /var/log/longclaw/frontend.log"
    echo ""
    echo "  常用命令:"
    echo "  - 停止服务: pkill -f 'uvicorn\|vite'"
    echo "  - 重启后端: cd $SCRIPT_DIR/backend && source venv/bin/activate && PYTHONPATH=. python -c \"import uvicorn; uvicorn.run('main:app', host='0.0.0.0', port=8001)\""
    echo "  - 重启前端: cd $SCRIPT_DIR/frontend && npm run dev"
    echo ""
}

# 主函数
main() {
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

    echo ""
    echo "=============================================="
    echo "  LongClaw 安装部署脚本"
    echo "=============================================="
    echo ""

    check_root
    detect_os
    check_dependencies

    echo ""
    echo "----------------------------------------------"
    echo "  开始配置"
    echo "----------------------------------------------"
    echo ""

    setup_mysql
    setup_redis
    setup_backend
    setup_frontend
    init_database
    start_services
    show_status
}

# 运行主函数
main "$@"
