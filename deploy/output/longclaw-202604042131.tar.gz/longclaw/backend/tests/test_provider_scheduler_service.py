"""
Tests for the Provider Scheduler Service.
"""
import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime

from backend.services.provider_scheduler_service import (
    ProviderSchedulerService,
    Priority,
    SlotAllocation,
    AgentState,
)


class TestProviderSchedulerService:
    """Test cases for ProviderSchedulerService."""

    @pytest.fixture
    def service(self):
        """Create a fresh service instance."""
        return ProviderSchedulerService()

    @pytest.fixture
    def mock_db_session(self):
        """Create a mock database session."""
        session = AsyncMock()
        return session

    def test_priority_constants(self):
        """Test priority level constants are properly defined."""
        assert Priority.RESIDENT_REPLY == 100
        assert Priority.REFLECT_CHECK == 90
        assert Priority.OWNER_PLANNING == 80
        assert Priority.OWNER_WAITING_WORKERS == 70
        assert Priority.WORKER_RUNNING == 60
        assert Priority.WORKER_WAITING_TOOL == 50
        assert Priority.IDLE == 10

    def test_slot_allocation_dataclass(self):
        """Test SlotAllocation dataclass creation."""
        allocation = SlotAllocation(
            agent_id="agent-123",
            provider_name="openai",
            model_name="gpt-4o",
            priority=Priority.RESIDENT_REPLY,
            priority_reason="Resident needs to reply",
            operation_type="resident_reply",
            task_id="task-456",
        )

        assert allocation.agent_id == "agent-123"
        assert allocation.provider_name == "openai"
        assert allocation.model_name == "gpt-4o"
        assert allocation.priority == 100
        assert allocation.operation_type == "resident_reply"
        assert allocation.task_id == "task-456"

    def test_agent_state_dataclass(self):
        """Test AgentState dataclass creation."""
        state = AgentState(
            agent_id="agent-123",
            agent_type=MagicMock(value="worker"),
            name="Test Worker",
            status=MagicMock(value="running"),
            task_id="task-456",
            parent_agent_id="owner-789",
            last_llm_call=datetime.utcnow(),
            last_heartbeat=datetime.utcnow(),
        )

        assert state.agent_id == "agent-123"
        assert state.name == "Test Worker"
        assert state.task_id == "task-456"
        assert state.parent_agent_id == "owner-789"
        assert state.is_waiting_for_reply is False
        assert state.is_waiting_for_tool is False
        assert state.worker_count == 0

    @pytest.mark.asyncio
    async def test_service_initial_state(self, service):
        """Test service initial state."""
        assert service._running is False
        assert service._scheduler_task is None
        assert service._check_interval == 1.0
        assert service._heartbeat_timeout == 60
        assert service._allocations == {}

    @pytest.mark.asyncio
    async def test_load_provider_config_defaults(self, service):
        """Test loading provider config with defaults."""
        # Mock the model_config_service
        with patch('backend.services.provider_scheduler_service.db_manager') as mock_db:
            mock_session = AsyncMock()
            mock_db.session.return_value.__aenter__.return_value = mock_session

            mock_config = MagicMock()
            mock_config.providers = [
                {
                    "name": "openai",
                    "max_parallel_requests": 10,
                    "models": [
                        {"name": "gpt-4o", "max_parallel_requests": 5}
                    ]
                }
            ]
            mock_config.default_provider = "openai"

            with patch('backend.services.model_config_service.model_config_service') as mock_service:
                mock_service.get_config = AsyncMock(return_value=mock_config)

                await service._load_provider_config()

                assert service._provider_total_max == {"openai": 10}
                assert service._provider_max_parallel == {"openai": {"gpt-4o": 5}}

    @pytest.mark.asyncio
    async def test_get_allocation_status_empty(self, service):
        """Test getting allocation status when no allocations."""
        status = await service.get_allocation_status()

        assert status["total_active"] == 0
        assert status["by_provider"] == {}
        assert status["allocations"] == []

    @pytest.mark.asyncio
    async def test_get_allocated_agent_count_empty(self, service):
        """Test getting allocated agent count when no allocations."""
        count = service.get_allocated_agent_count()
        assert count == 0

        count_with_provider = service.get_allocated_agent_count("openai")
        assert count_with_provider == 0

    @pytest.mark.asyncio
    async def test_try_allocate_no_capacity(self, service):
        """Test allocation when no capacity available."""
        # Set very low capacity - service needs model_max setup too
        service._provider_total_max = {"openai": 1}
        service._provider_max_parallel = {"openai": {"gpt-4o": 1}}

        request = SlotAllocation(
            agent_id="agent-1",
            provider_name="openai",
            model_name="gpt-4o",
            priority=Priority.WORKER_RUNNING,
            priority_reason="Worker running",
            operation_type="worker_execution",
        )

        # Without proper DB session, this won't create a real slot
        # Just verify the method handles the case gracefully
        with patch('backend.services.provider_scheduler_service.db_manager') as mock_db:
            mock_db.session.return_value.__aenter__.return_value = AsyncMock()
            result = await service._try_allocate(request)
            # Result depends on DB state, just verify no exception

    @pytest.mark.asyncio
    async def test_release_slot(self, service):
        """Test releasing a slot allocation."""
        # Create a mock slot
        mock_slot = MagicMock()
        mock_slot.id = "slot-123"
        mock_slot.agent_id = "agent-123"
        mock_slot.is_released = False

        service._allocations["agent-123"] = mock_slot

        with patch('backend.services.provider_scheduler_service.db_manager') as mock_db:
            mock_session = AsyncMock()
            mock_db.session.return_value.__aenter__.return_value = mock_session
            mock_session.execute = AsyncMock()

            await service._release_slot(mock_slot)

            assert mock_slot.is_released is True
            assert mock_slot.released_at is not None
            assert "agent-123" not in service._allocations

    @pytest.mark.asyncio
    async def test_get_agent_allocation_not_found(self, service):
        """Test getting allocation for agent with no slot."""
        allocation = await service.get_agent_allocation("nonexistent-agent")
        assert allocation is None

    @pytest.mark.asyncio
    async def test_heartbeat(self, service):
        """Test sending heartbeat for a slot."""
        mock_slot = MagicMock()
        mock_slot.id = "slot-123"
        mock_slot.agent_id = "agent-123"
        mock_slot.last_heartbeat = datetime.utcnow()

        service._allocations["agent-123"] = mock_slot

        with patch('backend.services.provider_scheduler_service.db_manager') as mock_db:
            mock_session = AsyncMock()
            mock_db.session.return_value.__aenter__.return_value = mock_session
            mock_session.execute = AsyncMock()

            await service.heartbeat("agent-123")

            assert mock_slot.last_heartbeat is not None


class TestResidentSlotAllocation:
    """Test cases for resident agent slot allocation with always_allocate config."""

    @pytest.fixture
    def service(self):
        """Create a fresh service instance."""
        return ProviderSchedulerService()

    @pytest.mark.asyncio
    async def test_should_resident_always_allocate_default(self, service):
        """Test that default value is True when config is not set."""
        with patch('backend.services.provider_scheduler_service.config_service') as mock_config:
            mock_config.get_bool = AsyncMock(return_value=True)
            result = await service._should_resident_always_allocate()
            assert result is True

    @pytest.mark.asyncio
    async def test_should_resident_always_allocate_false(self, service):
        """Test that False is returned when config is set to false."""
        with patch('backend.services.provider_scheduler_service.config_service') as mock_config:
            mock_config.get_bool = AsyncMock(return_value=False)
            result = await service._should_resident_always_allocate()
            assert result is False

    @pytest.mark.asyncio
    async def test_should_resident_always_allocate_exception(self, service):
        """Test that True is returned when config service throws exception."""
        with patch('backend.services.provider_scheduler_service.config_service') as mock_config:
            mock_config.get_bool = AsyncMock(side_effect=Exception("Config error"))
            result = await service._should_resident_always_allocate()
            assert result is True  # Default to True on error


class TestPriorityRules:
    """Test cases for priority allocation rules."""

    def test_priority_order(self):
        """Test that priorities are in correct order (higher = more urgent)."""
        priorities = [
            Priority.RESIDENT_REPLY,
            Priority.REFLECT_CHECK,
            Priority.OWNER_PLANNING,
            Priority.OWNER_WAITING_WORKERS,
            Priority.WORKER_RUNNING,
            Priority.WORKER_WAITING_TOOL,
            Priority.IDLE,
        ]

        # Check that each is greater than the next
        for i in range(len(priorities) - 1):
            assert priorities[i] > priorities[i + 1]

    def test_resident_reply_highest_priority(self):
        """Test that RESIDENT_REPLY has the highest priority."""
        priority_values = [
            v for k, v in Priority.__dict__.items()
            if not k.startswith('_') and isinstance(v, int)
        ]
        assert Priority.RESIDENT_REPLY == max(priority_values)

    def test_idle_lowest_priority(self):
        """Test that IDLE has the lowest priority."""
        all_priorities = [
            Priority.RESIDENT_REPLY,
            Priority.REFLECT_CHECK,
            Priority.OWNER_PLANNING,
            Priority.OWNER_WAITING_WORKERS,
            Priority.WORKER_RUNNING,
            Priority.WORKER_WAITING_TOOL,
            Priority.IDLE,
        ]
        assert Priority.IDLE == min(all_priorities)
